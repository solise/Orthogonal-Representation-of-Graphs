function d=ROgraph(G)
#
# generate the orthogonality representation (columns of resulting matrix) of a graph given by G
#
#************************

	e=0.00000000000001;									#numerical accuracy
	n=size(G)(1);
	d=3; 											#assumption that there exists a node connected to 2 other nodes
	iter=1;
	index=0;
	
	do
		A=rand(d,1)+i*rand(d,1);
		bad=false;
		for k=2:n 									# matrix A building loop
			C=zeros(1,d);
			for j=1:k-1 								# condition matrix building loop
				if G(k,j)
					C=[C;transpose(conj(A(:,j)))];
				endif
			end
			s=size(null(C))(2);
			x=null(C)*(rand(s,1)+i*rand(s,1));
			for j=1:k-1 								# checking loop
				if (rank([A(:,j),x],0.01)<2) || ((abs(A(:,j)'*x)<e) && G(j,k)==0) 	# parallelity or additional orthogonality
					bad=true;
					break;
				endif
			end
			if (bad && (index>=iter))
				d=d+1;
				if d>n
					bad=false;
					d=n;
				endif
                index=0;
				break;
            elseif (bad && (index<iter))
                index=index+1;
                break;
			else
				A=[A,x]; 							# check ok, add x as a next column of A
			endif
		end
	until !bad
	
	
	#print dimension
	dimension=d;
	
end


