## C�LCULO DEL COSTE DE UNA SOLUCI�N.  TRABAJO FIN DE MASTER.
##  Alberto Sol�s Encina. Copyright 2012. M�ster en matem�tica computacional
##Hay que considerar no s�lo que los vectores adyacentes sean ortogonales
##sino que aquellos que no los son tengan un producto escalar >0.

function [c]=Coste(S, G, n)
##Devuelve el coste asociado a una soluci�n S.

c = 0;
for i=1:n
    for j=1:n
        if G(i,j)==1
            c = c + abs( (S(:,i)')*(S(:,j)) );
        
        else
            if (abs( (S(:,i)')*(S(:,j)) ) == 0)
                c = c + 1;  ## Penalizaci�n: Si vectores no adyacentes resultan ser ortogonales, el coste aumenta
            endif
        endif
    end
end

c;
