## CLCULO DEL COSTE MNIMO PARA UN VECTOR.  TRABAJO FIN DE MASTER.
##  Alberto Sols Encina. Copyright 2012. Mster en matemtica computacional
##En el clculo del mnimo habr que considerar tambin que el vector no
##sea tab y que no est ya en la solucin.

function [min,vector,indice,costemejorado]=mincoste(n,d,S,G,costemejor)

##Devuelve el coste mnimo (min), el vector correspondiente a dicho coste (vector) y el
##ndice del vector que debe ser cambiado (indice) as como el coste mejor
##hasta ahora (costemin).


##Clculo del vector con coste mnimo
min=inf;
costemejorado=costemejor;

##Valores de inicializacin (el contenido al principio no es til)
vector=ones(1,n); 
indice=1;

for i=1:n
    for j=1:d
        R=S;
	random = rand();
	if (random <= 0.33)
        	R(j,i)=-1;
	elseif ((random > 0.33) && (random <= 0.66))
		R(j,i)=0;
	else
		R(j,i)=1;
	endif
        v=R(:,i);
        if (any(v) == 0)
            break;
	endif
        c=Coste(R,G,n);
        if (c<costemejorado)
            min=c;
            costemejorado=min;
            vector=v;
            indice=i;
        elseif (c<min && noTabu(v,S))
            min=c;
            vector=v;
            indice=i;
	endif
    end
end




