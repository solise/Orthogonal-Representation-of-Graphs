## REPRESENTACI�N ORTOGONAL. TRABAJO FIN DE MASTER
##  Alberto Sol�s Encina. Copyright 2012. M�ster en matem�tica computacional

function [S,coste]=Ortogonalrep(iteraciones,n,d,S,G)
coste=inf;
costemejor=Coste(S,G,n);


for m=1:iteraciones


[min,vector,indice,costemejorado]=mincoste(n,d,S,G,costemejor);
costemejor=costemejorado;

## En caso de que alguno sea mejor
if (min~=inf) 
    coste = min;
    S(:,indice)=vector;
endif
##sino esperamos a la iteraci�n siguiente

end

##Archivamos los resultados obtenidos
S;
coste;
