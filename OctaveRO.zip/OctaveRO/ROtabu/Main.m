## PROGRAMA DE LECTURA DE FICHERO DE GRAFOS con algoritmo TABU. TRABAJO FIN DE MASTER
##  Alberto Solís Encina. Copyright 2012. Máster en matemática computacional
## NOTA: Indicar en la variable 'n' el orden de los grafos de entrada.

fid = fopen('AMqg9.txt','r');
fid2 = fopen('ResultTabu9.txt', 'w');
counter=1;
n=9;
while ~feof(fid)
    G=zeros(n,n);
    for i=1:n
        fscanf(fid,'%c',1);
        A = fscanf(fid, '%d', n);
        if ~(isempty(A))
            G(i,:)=A;
        endif
    end
    if any(any(G))
        G;
    else 
        break;
    endif
    fscanf(fid,'%c',2);
    fscanf(fid,'\n',1);
    
    ##Realizar operaciones sobre el grafo G
    d = TabuOR(G);
    ##Almacenar los resultados en un fichero de Texto
    
    fprintf(fid2,'%d\t%d\r\n',counter,d);
    
    counter=counter+1;
    
end
fclose(fid);
fclose(fid2);
