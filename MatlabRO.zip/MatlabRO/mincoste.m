%% C�LCULO DEL COSTE M�NIMO PARA UN VECTOR
%%  Alberto Sol�s Encina. Copyright 2012. M�ster en matem�tica computacional
%%En el c�lculo del m�nimo habr� que considerar tambi�n que el vector no
%%sea tab� y que no est� ya en la soluci�n.

function [min,vector,indice,costemejorado]=mincoste(n,d,S,G,costemejor)
%%Devuelve el coste m�nimo (min), el vector correspondiente a dicho coste (vector) y el
%%�ndice del vector que debe ser cambiado (indice) as� como el coste mejor
%%hasta ahora (costemin).


%%C�lculo del vector con coste m�nimo
min=inf;
costemejorado=costemejor;

vector=ones(1,n); %Valores de inicializaci�n (el contenido no es �til)
indice=1;

for i=1:n
    for j=1:d
        R=S;
        R(j,i)=randi([-1 1],1,1);
        v=R(:,i);
        if (any(v) == 0)
            break;
        end
        c=Coste(R,G,n);
        if c<costemejorado %%Criterio de aspiraci�n por objetivo
            min=c;
            costemejorado=min;
            vector=v;
            indice=i;
        elseif c<min && noTabu(v,S)
            min=c;
            vector=v;
            indice=i;
        end
    end
end

min;
vector;
indice;
costemejorado;


