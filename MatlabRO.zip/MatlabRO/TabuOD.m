%% REPRESENTACI�N ORTOGONAL. OPTIMIZACI�N INFORM�TICA
%%  Alberto Sol�s Encina. Copyright 2012. M�ster en matem�tica computacional

function d=TabuOD(G)
%% Par�metros del problema
d=3; %%Dimensi�n del inicial del problema
iteraciones=10; %%N�mero de iteraciones sobre una dimensi�n
npruebas=1; %%N�mero de veces que se itera sobre la misma dimensi�n

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%El problema debe recibir como entrada: Dimendi�n (d), el n�mero de
%%v�rtices (n), la matriz de vectores (M), la soluci�n a mejorar (s) y 
%%la matriz del grafo(G).

%%Una soluci�n consiste en una matriz (dxn) con los vectores del grafo.
%%Podemos partir de una soluci�n inicial no factible.

%%Aqu� se generan el vector tab� (T) y se utiliza la matriz de costes (C) 
%%junto a la soluci�n (S).

n = size(G,1); %N�mero de vectores


costemin=inf;
Smin= zeros(d,n);
e=0.00000000000001;

bucles=0; %%Contador de n�mero de pruebas
bad=1;
%tiempo1=clock; %%Comenzamos a contabilizar el tiempo
while bad
    %%B�squeda de una soluci�n
    
     %%Creamos una soluci�n inicial aleatoria
        S = zeros(d,n);
        for i=1:n
            S(:,i) = randi([-1 1],1,d);
         if all(S(:,i)==zeros(d,1))
             S(1,i)=1;
         end
        end
        
        if (Coste(S,G,n) > costemin) %%Si el coste asociado a una soluci�n anterior es mejor, mantenerla.
            S=Smin;
        end
    
    %%Calculamos una soluci�n
    [S,coste]=Ortogonalrep(iteraciones,n,d,S,G);
    if coste<costemin
        costemin=coste;
        Smin=S;
    end
    
    if costemin < e
        bad=0;
        break;
    end
    if (bucles >= npruebas)
         d = d+1;
         if d>n
			bad=0;
			d=n;
         end
         bucles=0;
         costemin=inf; 
    else
        bucles=bucles+1;
    end
    
end
S;
%tiempo2 = etime(clock,tiempo1)
%dimension=d
%display('Soluci�n m�nima encontrada')
%Smin
%display('Coste asociado')
%costemin



                