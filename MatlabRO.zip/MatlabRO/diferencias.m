%% PROGRAMA DE CALCULO DE DIFERENCIAS EN LOS RESULTADOS
fid = fopen('Resultro8.txt','r');
fid2 = fopen('ResultTabu8.txt', 'r');
cequal=0; %%Casos en los que son iguales
csmall=0; %%Casos en los que el segundo es mayor que el primero
cdistn =0; %%Casos en los que son distintos

while (~feof(fid) && ~feof(fid2))
    fscanf(fid,'%d',1);
     fscanf(fid,'%c',1);
    gram = fscanf(fid,'%d',1)
    fscanf(fid,'\n',1);
    
    fscanf(fid2,'%d',1);
    fscanf(fid2,'%c',1);
    tabu = fscanf(fid2,'%d',1)
    fscanf(fid2,'\n',1);
  
    if gram == tabu
        cequal = cequal +1;
    elseif tabu < gram
        csmall = csmall+1;
        cdistn = cdistn+1;
    else
        cdistn = cdistn+1;
    end
    
end
fclose(fid);
fclose(fid2);

cequal
csmall
cdistn
