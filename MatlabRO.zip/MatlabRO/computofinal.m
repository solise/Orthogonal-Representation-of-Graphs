%% PROGRAMA DE OBTENCI�N DE RESULTADOS GLOBALES

function [ret]=computofinal(n)
in1 =  sprintf('Resultro%d.txt', n);
in2 = sprintf('ResultTabu%d.txt', n);
in3 = sprintf('qg%d.g6', n);
in4 = sprintf('ResultadoFinal%d.txt', n);

fid = fopen(in1,'r');
fid2 = fopen(in2, 'r');
fid3= fopen(in3, 'r');
fid4 =  fopen(in4, 'w');


while (~feof(fid) && ~feof(fid2) && ~feof(fid3) && ~feof(fid4))
    fscanf(fid,'%d',1);
     fscanf(fid,'%c',1);
    gram = fscanf(fid,'%d',1);
    fscanf(fid,'\n',1);
    
    fscanf(fid2,'%d',1);
    fscanf(fid2,'%c',1);
    tabu = fscanf(fid2,'%d',1);
    fscanf(fid2,'\n',1);
    
    string = fscanf(fid3,'%s',1);
    fscanf(fid3,'\n',1);
  
    if gram == tabu
        mejor = gram;
    elseif tabu < gram
        mejor = tabu;
    else
        mejor = gram;
    end
    
    fprintf(fid4,'%s\t\t\t%d\r\n',string,mejor);
    
end
fclose(fid);
fclose(fid2);
fclose(fid3);
fclose(fid4);
ret=1;
