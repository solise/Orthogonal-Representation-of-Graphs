%% Comprueba la validez de una soluci�n a trav�s de la matriz de gramm
function B=correct(A,G)
    e=0.00000000000001;
    n=size(G,1); 
	B = (transpose(A))*A;				% Genera la matriz de Gramm B desde la matriz A
	for k=1:size(B,1)					    % Cambia la matriz de Gramm B a una matriz ortogonal (bucle que recorre toda la matriz B)
		for j=1:size(B,2)
            B(k,j)=abs(B(k,j));
			if abs(B(k,j))<e
				B(k,j)=1;
			else
				B(k,j)=0;
            end
		end
    end
    % La matriz B resultante debe corresponder a la matriz de adyacencia
    % para que el resultado sea correcto (en caso contrario se tienen
    % adyacencias adicionales).
    lab = B
    difer=B-G
	additional_orthogonalities=ones(1,n)*(B-G)*ones(n,1)/2	%count ones in difference B-G, divide by 2 (additional orthogonalities)
	B-G % El conjunto de vectores es correcto si dicha matriz resulta nula