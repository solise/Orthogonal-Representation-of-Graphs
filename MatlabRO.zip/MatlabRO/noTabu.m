%% COMPROBACI�N DE SI UN VECTOR ES TAB�
%%  Alberto Sol�s Encina. Copyright 2012. M�ster en matem�tica computacional
%%Basta ver si no pertence a la lista tab� y si no pertence ya a la
%%soluci�n


function [respuesta]=noTabu(v,S)
%%Devuelve si un vector es considerado no tab� = ya est� en la soluci�n.

i=1; nocontenido=1;
while (i<=size(S,2) && nocontenido)
    if ( isequal(v,S(:,i))  || (rank([v S(:,i)])<2) ) 
        nocontenido=0;
    end
    i=i+1;
end   

respuesta=nocontenido;